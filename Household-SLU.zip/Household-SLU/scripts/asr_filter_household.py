#!/usr/bin/env python3
"""
Whisper check of every synthesised clip (run after synthesis, before finalize).

Writes metadata/asr_check.csv (sample_id|split|speaker_id|tone|wer|ent_wer|keep|text|hypothesis).
`wer` is the word error rate of the whole sentence, `ent_wer` the share of slot-filler words missing from the
transcript (a clip whose entities were garbled cannot be trusted even if the rest is fine).
finalize_household.py drops clips with keep=0. Resumable.

  pip install faster-whisper num2words     (or openai-whisper)
  python scripts/asr_filter_household.py --max_wer 0.2 --max_ent_wer 0.0 --model small.en
"""
import argparse, csv, json, re
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
try:
    from num2words import num2words
except ImportError:
    num2words = None
ABBREV = {"mr": "mister", "mrs": "missus", "dr": "doctor", "ok": "okay", "tshirt": "t shirt",
          "tshirts": "t shirts", "ereader": "e reader", "ewaste": "e waste", "favor": "favour",
          "organise": "organize", "neighbor": "neighbour", "neighbors": "neighbours", "pyjamas": "pajamas",
          "grey": "grey", "gray": "grey"}


def norm(text):
    t = text.lower().replace("%", " percent")
    if num2words:
        t = re.sub(r"\d+", lambda m: " " + num2words(int(m.group())) + " ", t)
    t = re.sub(r"[-_/]", " ", t)
    t = re.sub(r"[^a-z0-9' ]", "", t).replace("'", "")
    return " ".join(ABBREV.get(w, w) for w in t.split()).split()


def wer(ref, hyp):
    r, h = norm(ref), norm(hyp)
    d = list(range(len(h) + 1))
    for i in range(1, len(r) + 1):
        prev, d[0] = d[0], i
        for j in range(1, len(h) + 1):
            prev, d[j] = d[j], min(d[j] + 1, d[j - 1] + 1, prev + (r[i - 1] != h[j - 1]))
    return d[len(h)] / max(len(r), 1)


def ent_wer(fillers, hyp):
    h = " " + " ".join(norm(hyp)) + " "
    miss = sum(1 for f in fillers if " " + " ".join(norm(f)) + " " not in h)
    return miss / len(fillers) if fillers else 0.0


def load_asr(name, device):
    try:
        from faster_whisper import WhisperModel
        m = WhisperModel(name, device=device, compute_type="float16" if device == "cuda" else "int8")
        return lambda p: " ".join(s.text for s in m.transcribe(p, language="en", beam_size=5)[0])
    except ImportError:
        import whisper
        m = whisper.load_model(name, device=device)
        return lambda p: m.transcribe(p, language="en")["text"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max_wer", type=float, default=0.2)
    ap.add_argument("--max_ent_wer", type=float, default=0.0, help="0 = every slot filler must be recognised")
    ap.add_argument("--model", default="small.en")
    ap.add_argument("--device", default="cuda")
    a = ap.parse_args()

    fillers = {}
    for sp in ("train", "devel", "test"):
        for l in open(ROOT / f"dataset/household/{sp}.jsonl"):
            r = json.loads(l)
            fillers[str(r["slurp_id"])] = re.findall(r"\[\s*[a-z_]+\s*:\s*([^\]]+?)\s*\]", r["sentence_annotation"])
    jobs = list(csv.DictReader(open(ROOT / "metadata/tts_jobs.csv")))
    out = ROOT / "metadata/asr_check.csv"
    cols = ["sample_id", "split", "speaker_id", "tone", "wer", "ent_wer", "keep", "text", "hypothesis"]
    done = {r["sample_id"]: r for r in csv.DictReader(open(out), delimiter="|")} if out.exists() else {}
    f = open(out, "a", newline="")
    w = csv.DictWriter(f, fieldnames=cols, delimiter="|")
    if not done:
        w.writeheader()
    asr = None
    for j in jobs:
        p = ROOT / "audio_raw" / j["file"]
        if j["sample_id"] in done or not p.exists():
            continue
        asr = asr or load_asr(a.model, a.device)
        hyp = asr(str(p)).strip()
        e, ee = wer(j["text"], hyp), ent_wer(fillers[j["slurp_id"]], hyp)
        row = {"sample_id": j["sample_id"], "split": j["split"], "speaker_id": j["speaker_id"], "tone": j["tone"],
               "wer": f"{e:.3f}", "ent_wer": f"{ee:.3f}", "keep": int(e <= a.max_wer and ee <= a.max_ent_wer),
               "text": j["text"], "hypothesis": hyp}
        w.writerow(row); f.flush()
        done[j["sample_id"]] = row
        print(("ok  " if row["keep"] else "DROP"), f"{e:.2f} {ee:.2f}", j["sample_id"], "|", hyp)
    f.close()
    for key in ("tone", "speaker_id", "split"):
        tot, ok = defaultdict(int), defaultdict(int)
        for r in done.values():
            tot[r[key]] += 1; ok[r[key]] += int(r["keep"])
        print(f"\npass rate by {key}:")
        for k in sorted(tot):
            print(f"  {k:12s} {ok[k]:6d}/{tot[k]:<6d} {100 * ok[k] / tot[k]:5.1f}%")
    print(f"\nchecked {len(done)} clips, {sum(int(r['keep']) for r in done.values())} kept")


if __name__ == "__main__":
    main()
