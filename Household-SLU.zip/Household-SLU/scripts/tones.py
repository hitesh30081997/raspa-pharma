"""Speaking tones used per utterance. A designed voice gets one reference clip per tone; the Base
model clones that clip, so the speaker identity stays while the tone changes.

  design   : phrase appended to the speaker's voice description for VoiceDesign
  ref_text : sentence spoken in that tone to build the reference clip
  weight   : share of utterances that get this tone
"""

TONES = {
    "neutral": {"weight": 0.25,
                "design": "speaking in a neutral, matter-of-fact way",
                "ref_text": "Hello, I am going to read a few short sentences for you in my normal speaking voice."},
    "friendly": {"weight": 0.15,
                 "design": "speaking in a warm, friendly and polite way",
                 "ref_text": "Hi there, thanks so much for helping me around the house, it really means a lot."},
    "cheerful": {"weight": 0.10,
                 "design": "sounding cheerful and upbeat, smiling while speaking",
                 "ref_text": "What a lovely morning! Everything is going so well today, I feel great."},
    "calm": {"weight": 0.10,
             "design": "sounding calm and relaxed, speaking gently",
             "ref_text": "There is no hurry at all. Take your time, and we can do everything slowly."},
    "tired": {"weight": 0.10,
              "design": "sounding tired and sleepy, with low energy",
              "ref_text": "It has been such a long day. I am really tired and I just want to rest now."},
    "impatient": {"weight": 0.10,
                  "design": "sounding impatient and a little annoyed",
                  "ref_text": "I have already asked for this twice. Please just get it done properly this time."},
    "hurried": {"weight": 0.10,
                "design": "speaking quickly, as if in a hurry",
                "ref_text": "Quick, quick, I am running late for work, I need to leave in two minutes."},
    "sad": {"weight": 0.10,
            "design": "sounding sad and downcast, speaking quietly",
            "ref_text": "I am not feeling very good today. Everything seems a bit heavy and slow."},
}
