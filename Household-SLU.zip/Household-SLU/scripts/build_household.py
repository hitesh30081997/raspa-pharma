#!/usr/bin/env python3
"""
Build the Household-SLU text dataset, the 50-speaker plan and the TTS job list.

  python scripts/build_household.py [--per_intent 100] [--train_readers 11] [--slurp_sentences FILE]

Outputs
  dataset/household/{train,devel,test}.jsonl   SLURP-format records (recordings filled in by finalize)
  metadata/ontology.json                       scenario, 30 intents, slot types with example fillers
  metadata/speakers.json / speakers.csv        50 designed voices and their split
  metadata/tts_jobs.csv                        one row per audio sample to synthesise (30,000 by default)
  text/sentences.txt                           one unique command per line
  text/sentences_annotated.tsv                 slurp_id, split, intent, sentence, annotation
  metadata/build_report.txt                    counts and checks
"""
import argparse, csv, json, random, re, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
sys.path.insert(0, str(ROOT / "scripts"))
import household_templates as H  # noqa: E402
from tones import TONES  # noqa: E402

SLOT_TYPES = ["item", "gadget", "garment", "linen", "dish", "food", "meal", "drink", "plant", "pet", "person",
              "location", "destination", "fixture", "appliance", "state", "bag", "waste", "quantity", "color",
              "time", "date"]
SLURP_ACTIONS = {  # from the user's SLURP_inventory.xlsx (Actions sheet)
    "addcontact", "affirm", "audiobook", "cleaning", "coffee", "commandstop", "confirm", "convert", "createoradd",
    "currency", "definition", "dislikeness", "dontcare", "events", "explain", "factoid", "game", "greet",
    "hue_lightchange", "hue_lightdim", "hue_lightoff", "hue_lighton", "hue_lightup", "joke", "likeness",
    "locations", "maths", "movies", "music", "negate", "order", "podcasts", "post", "praise", "query",
    "querycontact", "quirky", "radio", "recipe", "remove", "repeat", "sendemail", "set", "settings", "stock",
    "taxi", "ticket", "traffic", "volume_down", "volume_mute", "volume_other", "volume_up", "wemo_off", "wemo_on"}
SLURP_SCENARIOS = {"alarm", "audio", "calendar", "cooking", "datetime", "email", "general", "iot", "lists", "music",
                   "news", "play", "qa", "recommendation", "social", "takeaway", "transport", "weather"}
SLOT_RE = re.compile(r"\{(\w+)(?:=(\w+))?\}")
ANN_RE = re.compile(r"\[\s*([a-z_]+)\s*:\s*([^\]]+?)\s*\]")

# ------------------------------------------------------------------ speakers ---
ACCENTS = ["a General American accent", "a Southern American accent", "a British Received Pronunciation accent",
           "a Northern English accent", "a Scottish accent", "an Irish accent", "an Australian accent",
           "an Indian English accent", "a South African accent", "a Nigerian English accent"]
ACCENT_SHORT = ["us_general", "us_southern", "uk_rp", "uk_northern", "scottish", "irish", "australian",
                "indian", "south_african", "nigerian"]
AGES = ["teenage", "young adult", "adult in their thirties", "middle-aged", "elderly"]
AGE_SHORT = ["teen", "young_adult", "thirties", "middle_aged", "elderly"]
PITCH = {"female": ["low-pitched", "medium-pitched", "medium-pitched", "high-pitched"],
         "male": ["deep, low-pitched", "low-pitched", "medium-pitched", "slightly high-pitched"]}
TIMBRE = ["warm", "bright", "husky", "smooth", "resonant", "slightly nasal", "soft and breathy", "crisp and clear",
          "gravelly", "rich", "light", "raspy"]
PACE = ["slow", "moderate", "moderate", "fast"]
MANNER = ["calm", "friendly", "confident", "energetic", "gentle", "serious", "cheerful", "relaxed", "brisk"]


def make_speakers(rng):
    spk = []
    for a in range(len(ACCENTS)):
        for j in range(5):
            g = "female" if (a + j) % 2 == 0 else "male"
            age = (a + 2 * j) % 5  # 5 different ages per accent -> every (gender, age, accent) is unique
            p, t, pace, m = rng.choice(PITCH[g]), rng.choice(TIMBRE), rng.choice(PACE), rng.choice(MANNER)
            desc = (f"A {m} {AGES[age]} {g} voice, {p} and {t}, speaking at a {pace} pace "
                    f"with {ACCENTS[a]}")
            spk.append({"speaker_id": f"spk{len(spk) + 1:03d}", "gender": g, "age": AGE_SHORT[age],
                        "accent": ACCENT_SHORT[a], "pitch": p, "timbre": t, "pace": pace, "manner": m,
                        "description": desc + "."})
    return spk


def split_speakers(spk, n_dev, n_test, rng):
    """Disjoint dev/test speakers: gender-balanced, all different accents, varied ages."""
    for _ in range(20000):
        pick = rng.sample(range(len(spk)), n_dev + n_test)
        dev, test = pick[:n_dev], pick[n_dev:]
        ok = True
        for grp in (dev, test):
            g = Counter(spk[i]["gender"] for i in grp)
            if abs(g["female"] - g["male"]) > 1 or len({spk[i]["accent"] for i in grp}) < len(grp) \
                    or len({spk[i]["age"] for i in grp}) < min(4, len(grp)):
                ok = False
        if ok:
            for i, s in enumerate(spk):
                s["split"] = "devel" if i in dev else "test" if i in test else "train"
            return
    sys.exit("could not find a balanced speaker split")


# ------------------------------------------------------------------ text ---
def realise(template, rng):
    full = template.startswith("!")
    core = template[1:] if full else template
    used = defaultdict(set)

    def fill(m):
        stype, lex = m.group(1), m.group(2) or m.group(1)
        assert stype in SLOT_TYPES, f"unknown slot type {stype} in: {template}"
        vals = [v for v in H.LEX[lex] if v not in used[stype]]
        v = rng.choice(vals)
        used[stype].add(v)
        return f"[{stype} : {v}]"

    ann = SLOT_RE.sub(fill, core)
    if not full:
        has_tdate = "{time" in core or "{date" in core
        options = [w for w in H.WRAPPERS
                   if not (w in H.SUFFIX_WRAPPERS and (has_tdate or " for " in core))]
        w = rng.choice(options)
        ann = w.replace("{c}", ann)
    return ann


def parse(annot):
    words, ents, pos = [], [], 0
    for m in ANN_RE.finditer(annot):
        words += annot[pos:m.start()].split()
        fw = m.group(2).split()
        ents.append({"type": m.group(1), "filler": m.group(2), "span": list(range(len(words), len(words) + len(fw)))})
        words += fw
        pos = m.end()
    words += annot[pos:].split()
    return " ".join(words), ents


def semantics(action, ents):
    return str({"scenario": H.SCENARIO, "action": action,
                "entities": [{"type": e["type"], "filler": e["filler"]} for e in ents]})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--per_intent", type=int, default=100)
    ap.add_argument("--split", type=int, nargs=3, default=[80, 10, 10], metavar=("TRAIN", "DEVEL", "TEST"))
    ap.add_argument("--speakers", type=int, nargs=3, default=[38, 6, 6], metavar=("TRAIN", "DEVEL", "TEST"))
    ap.add_argument("--train_readers", type=int, default=11, help="train speakers per train sentence")
    ap.add_argument("--slurp_sentences", default=None, help="JSON list of SLURP sentences for an overlap check")
    ap.add_argument("--seed", type=int, default=2026)
    a = ap.parse_args()
    assert sum(a.split) == a.per_intent
    rng = random.Random(a.seed)

    # ---- checks against SLURP label names
    acts = list(H.INTENTS)
    assert H.SCENARIO not in SLURP_SCENARIOS
    clash = [x for x in acts if x in SLURP_ACTIONS]
    assert not clash, f"actions also in SLURP: {clash}"
    for lex, vals in H.LEX.items():
        for v in vals:
            assert v == v.lower() and not re.search(r"\d|'", v), f"bad lexicon value {lex}: {v}"

    # ---- sentences
    seen, records = set(), []
    for action, (desc, temps) in H.INTENTS.items():
        got, tries, t_i = [], 0, 0
        order = temps[:]
        rng.shuffle(order)
        while len(got) < a.per_intent:
            tries += 1
            assert tries < 50000, f"{action}: cannot reach {a.per_intent} unique sentences"
            ann = realise(order[t_i % len(order)], rng)
            t_i += 1
            sent, ents = parse(ann)
            if sent in seen:
                continue
            assert not re.search(r"[\[\]{}]", sent), sent
            seen.add(sent)
            got.append((sent, ann, ents))
        rng.shuffle(got)
        n_tr, n_dv, _ = a.split
        for k, (sent, ann, ents) in enumerate(got):
            records.append({"action": action, "sentence": sent, "sentence_annotation": ann, "entities": ents,
                            "split": "train" if k < n_tr else "devel" if k < n_tr + n_dv else "test"})
    for i, r in enumerate(records):
        r["slurp_id"] = 900001 + i  # >= 900001 so ids never clash with SLURP

    slurp_overlap = None
    if a.slurp_sentences:
        ss = set(json.load(open(a.slurp_sentences)))
        slurp_overlap = sorted(r["sentence"] for r in records if r["sentence"] in ss)

    # ---- speakers
    spk = make_speakers(rng)
    split_speakers(spk, a.speakers[1], a.speakers[2], rng)
    by_split = {s: [x["speaker_id"] for x in spk if x["split"] == s] for s in ("train", "devel", "test")}
    assert [len(by_split[s]) for s in ("train", "devel", "test")] == a.speakers

    # ---- TTS jobs: who reads what, in which tone, at which speed
    tone_names = list(TONES)
    tone_w = [TONES[t]["weight"] for t in tone_names]
    jobs = []
    train = [r for r in records if r["split"] == "train"]
    rng.shuffle(train)
    tr_spk = by_split["train"][:]
    for k, r in enumerate(train):  # cyclic assignment -> every train speaker reads the same number of sentences
        r["readers"] = [tr_spk[(k * a.train_readers + j) % len(tr_spk)] for j in range(a.train_readers)]
    for r in records:
        if r["split"] != "train":
            r["readers"] = by_split[r["split"]][:]
    for r in sorted(records, key=lambda x: x["slurp_id"]):
        for s in r["readers"]:
            jr = random.Random(f"{a.seed}-{r['slurp_id']}-{s}")
            tone = jr.choices(tone_names, tone_w)[0]
            speed = jr.choices([0.9, 1.0, 1.1], [0.2, 0.6, 0.2])[0] if r["split"] == "train" else 1.0
            jobs.append({"sample_id": f"hh-{r['slurp_id']}-{s}", "slurp_id": r["slurp_id"], "split": r["split"],
                         "speaker_id": s, "tone": tone, "speed": speed, "intent": f"{H.SCENARIO}_{r['action']}",
                         "text": r["sentence"], "file": f"{r['split']}/{s}/hh-{r['slurp_id']}-{s}.wav"})

    # ---- write SLURP-format jsonl
    out = ROOT / "dataset/household"
    out.mkdir(parents=True, exist_ok=True)
    for sp in ("train", "devel", "test"):
        with open(out / f"{sp}.jsonl", "w") as f:
            for r in records:
                if r["split"] != sp:
                    continue
                toks = r["sentence"].split()
                f.write(json.dumps({
                    "slurp_id": r["slurp_id"], "sentence": r["sentence"],
                    "sentence_annotation": r["sentence_annotation"],
                    "intent": f"{H.SCENARIO}_{r['action']}", "action": r["action"],
                    "tokens": [{"surface": w, "id": i, "lemma": w, "pos": None} for i, w in enumerate(toks)],
                    "scenario": H.SCENARIO,
                    "recordings": [{"file": f"hh-{r['slurp_id']}-{s}.wav", "wer": None, "ent_wer": None,
                                    "status": "planned"} for s in r["readers"]],
                    "entities": [{"span": e["span"], "type": e["type"]} for e in r["entities"]],
                    "semantics": semantics(r["action"], r["entities"]),
                }) + "\n")

    # ---- metadata
    md = ROOT / "metadata"
    md.mkdir(exist_ok=True)
    slot_vals = defaultdict(Counter)
    for r in records:
        for e in r["entities"]:
            slot_vals[e["type"]][e["filler"]] += 1
    onto = {"scenario": H.SCENARIO, "base_model": "nvidia/slu_conformer_transformer_large_slurp",
            "audio": {"sample_rate": 16000, "channels": 1, "format": "wav PCM-16"},
            "intents": {f"{H.SCENARIO}_{k}": {"action": k, "description": v[0],
                                               "slot_types": sorted({e['type'] for r in records if r['action'] == k
                                                                     for e in r['entities']})}
                        for k, v in H.INTENTS.items()},
            "slot_types": {t: {"occurrences": sum(slot_vals[t].values()), "unique_fillers": len(slot_vals[t]),
                               "examples": [v for v, _ in slot_vals[t].most_common(8)]}
                           for t in SLOT_TYPES if t in slot_vals},
            "tones": {k: v["weight"] for k, v in TONES.items()},
            "speed_perturbation": "train only: 0.9 (20%), 1.0 (60%), 1.1 (20%); devel/test 1.0"}
    json.dump(onto, open(md / "ontology.json", "w"), indent=2)
    json.dump(spk, open(md / "speakers.json", "w"), indent=2)
    with open(md / "speakers.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(spk[0]))
        w.writeheader(); w.writerows(spk)
    with open(md / "tts_jobs.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(jobs[0]))
        w.writeheader(); w.writerows(jobs)
    (ROOT / "text").mkdir(exist_ok=True)
    recs_sorted = sorted(records, key=lambda x: x["slurp_id"])
    (ROOT / "text/sentences.txt").write_text("\n".join(r["sentence"] for r in recs_sorted) + "\n")
    with open(ROOT / "text/sentences_annotated.tsv", "w", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        w.writerow(["slurp_id", "split", "intent", "sentence", "sentence_annotation"])
        for r in recs_sorted:
            w.writerow([r["slurp_id"], r["split"], f"{H.SCENARIO}_{r['action']}", r["sentence"],
                        r["sentence_annotation"]])

    # ---- report
    js = Counter(j["split"] for j in jobs)
    per_spk = Counter(j["speaker_id"] for j in jobs if j["split"] == "train")
    lines = [f"intents: {len(H.INTENTS)}   slot types: {len(slot_vals)}   unique sentences: {len(records)}",
             "sentences per split: " + ", ".join(f"{s}={sum(r['split'] == s for r in records)}"
                                                   for s in ("train", "devel", "test")),
             f"speakers: {len(spk)} -> " + ", ".join(f"{s}={len(v)}" for s, v in by_split.items()),
             "speaker sets disjoint: " + str(not (set(by_split['train']) & set(by_split['devel'])
                                                  or set(by_split['train']) & set(by_split['test'])
                                                  or set(by_split['devel']) & set(by_split['test']))),
             "audio samples: " + ", ".join(f"{s}={js[s]}" for s in ("train", "devel", "test")) + f"  total={len(jobs)}",
             f"train sentences per train speaker: min={min(per_spk.values())} max={max(per_spk.values())}",
             "tones: " + ", ".join(f"{k}={v}" for k, v in Counter(j['tone'] for j in jobs).most_common()),
             "speeds (train): " + ", ".join(f"{k}={v}" for k, v in sorted(Counter(j['speed'] for j in jobs if j['split'] == 'train').items())),
             f"action names shared with SLURP: {clash or 'none'}   scenario in SLURP: {H.SCENARIO in SLURP_SCENARIOS}",
             f"sentences identical to a SLURP sentence: {'not checked' if slurp_overlap is None else len(slurp_overlap)}"
             + (f" {slurp_overlap[:10]}" if slurp_overlap else "")]
    for s in ("devel", "test"):
        lines.append(f"{s} speakers: " + "; ".join(f"{x['speaker_id']} {x['gender']} {x['age']} {x['accent']}"
                                                   for x in spk if x["split"] == s))
    (md / "build_report.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
