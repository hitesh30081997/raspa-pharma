#!/usr/bin/env python3
"""
After synthesis (and optionally asr_filter_household.py):
  * converts audio_raw/... to 16 kHz mono PCM-16 in audio/...,
    applying the per-sample speed perturbation from tts_jobs.csv (Kaldi-style: tempo and pitch change together)
  * drops clips that failed the ASR check (keep=0 in metadata/asr_check.csv)
  * writes NeMo manifests       manifests/{train,devel,test}_slu.json
  * fills SLURP "recordings"    dataset/household/{train,devel,test}.jsonl
  * writes metadata/recordings.csv (one row per final clip, with speaker, tone, speed, duration)

  pip install soundfile scipy numpy
  python scripts/finalize_household.py [--absolute] [--workers 8]
"""
import argparse, csv, json
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

ROOT = Path(__file__).resolve().parents[1]
SR = 16000


def convert(args):
    src, dst, speed = args
    wav, sr = sf.read(src, dtype="float32", always_2d=True)
    wav = wav.mean(axis=1)
    # playing sr*speed samples per second = speed-up by `speed`; resample that to 16 kHz
    fr = Fraction(SR, int(round(sr * speed))).limit_denominator(1000)
    if fr != 1:
        wav = resample_poly(wav, fr.numerator, fr.denominator)
    peak = float(np.abs(wav).max()) or 1.0
    if peak > 0.99:
        wav = wav / peak * 0.95
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    sf.write(dst, wav, SR, subtype="PCM_16")
    return len(wav) / SR


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--absolute", action="store_true", help="absolute audio paths in the NeMo manifests")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--no_speed", action="store_true", help="ignore speed perturbation")
    a = ap.parse_args()

    jobs = list(csv.DictReader(open(ROOT / "metadata/tts_jobs.csv")))
    asr = {}
    if (ROOT / "metadata/asr_check.csv").exists():
        asr = {r["sample_id"]: r for r in csv.DictReader(open(ROOT / "metadata/asr_check.csv"), delimiter="|")}
    todo, skipped, rejected = [], 0, 0
    for j in jobs:
        src = ROOT / "audio_raw" / j["file"]
        if not src.exists():
            skipped += 1; continue
        if j["sample_id"] in asr and asr[j["sample_id"]]["keep"] == "0":
            rejected += 1; continue
        todo.append(j)
    args = [(str(ROOT / "audio_raw" / j["file"]), str(ROOT / "audio" / j["file"]),
             1.0 if a.no_speed else float(j["speed"])) for j in todo]
    with ProcessPoolExecutor(a.workers) as ex:
        durs = list(ex.map(convert, args, chunksize=32))

    recs, split_of = {}, {}
    for sp in ("train", "devel", "test"):
        for l in open(ROOT / f"dataset/household/{sp}.jsonl"):
            r = json.loads(l)
            r["recordings"] = []
            recs[str(r["slurp_id"])] = r
            split_of[str(r["slurp_id"])] = sp
    man = {"train": [], "devel": [], "test": []}
    rows = []
    for j, d in zip(todo, durs):
        r = recs[j["slurp_id"]]
        p = ROOT / "audio" / j["file"]
        path = str(p.resolve()) if a.absolute else str(p.relative_to(ROOT))
        man[j["split"]].append({"audio_filepath": path, "offset": 0.0, "duration": round(d, 3), "text": r["semantics"]})
        q = asr.get(j["sample_id"], {})
        r["recordings"].append({"file": Path(j["file"]).name, "wer": float(q["wer"]) if q else None,
                                "ent_wer": float(q["ent_wer"]) if q else None,
                                "status": "synthetic", "speaker_id": j["speaker_id"], "tone": j["tone"],
                                "speed": float(j["speed"])})
        rows.append([j["sample_id"], j["split"], j["speaker_id"], j["tone"], j["speed"], round(d, 3), path])

    (ROOT / "manifests").mkdir(exist_ok=True)
    for sp, lines in man.items():
        with open(ROOT / f"manifests/{sp}_slu.json", "w") as f:
            for x in lines:
                f.write(json.dumps(x) + "\n")
        with open(ROOT / f"dataset/household/{sp}.jsonl", "w") as f:
            for k, r in recs.items():  # every sentence is kept; recordings lists only the final clips
                if split_of[k] == sp:
                    f.write(json.dumps(r) + "\n")
    with open(ROOT / "metadata/recordings.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["sample_id", "split", "speaker_id", "tone", "speed", "duration", "audio_filepath"])
        w.writerows(rows)
    for sp, lines in man.items():
        print(f"{sp:6s} {len(lines):6d} clips  {sum(x['duration'] for x in lines) / 3600:6.2f} h")
    print(f"missing audio: {skipped}   rejected by ASR check: {rejected}")



if __name__ == "__main__":
    main()
