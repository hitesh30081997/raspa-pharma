#!/usr/bin/env python3
"""
Speaker checks with a speaker-verification model (SpeechBrain ECAPA-TDNN). Run after `--stage refs`
(and again after cloning with --clips).

1. Tone consistency : each speaker's tone reference vs its neutral reference. A low similarity means
                      VoiceDesign drifted to a different-sounding person for that tone -> delete that
                      reference and re-run  synth_household_qwen3.py --stage refs --ref_seed_offset 1
2. Split leakage    : every devel/test speaker vs every train speaker (neutral references). A devel/test
                      voice that is nearly identical to a train voice weakens the speaker-disjoint split.
3. --clips N        : N random final clips per speaker vs that speaker's neutral reference (clone fidelity).

  pip install speechbrain
  python scripts/check_speakers.py [--tone_min 0.55] [--leak_max 0.75] [--clips 5]
Writes metadata/speaker_check.csv.
"""
import argparse, csv, json, random
from pathlib import Path

import torch
import torchaudio

ROOT = Path(__file__).resolve().parents[1]


def load_encoder(device):
    try:
        from speechbrain.inference.speaker import EncoderClassifier
    except ImportError:
        from speechbrain.pretrained import EncoderClassifier
    return EncoderClassifier.from_hparams(source="speechbrain/spkrec-ecapa-voxceleb",
                                          savedir=str(ROOT / ".cache/ecapa"), run_opts={"device": device})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tone_min", type=float, default=0.55)
    ap.add_argument("--leak_max", type=float, default=0.75)
    ap.add_argument("--clips", type=int, default=0)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    a = ap.parse_args()
    enc = load_encoder(a.device)
    cache = {}

    def emb(path):
        if path not in cache:
            wav, sr = torchaudio.load(path)
            wav = torchaudio.functional.resample(wav.mean(0, keepdim=True), sr, 16000)
            cache[path] = torch.nn.functional.normalize(enc.encode_batch(wav.to(a.device)).squeeze(), dim=0).cpu()
        return cache[path]

    spk = json.load(open(ROOT / "metadata/speakers.json"))
    refs = ROOT / "metadata/voice_refs"
    rows = []
    neutral = {s["speaker_id"]: emb(str(refs / f"{s['speaker_id']}__neutral.wav"))
               for s in spk if (refs / f"{s['speaker_id']}__neutral.wav").exists()}
    for p in sorted(refs.glob("*__*.wav")):
        s, t = p.stem.split("__")
        if t == "neutral" or s not in neutral:
            continue
        c = float(neutral[s] @ emb(str(p)))
        rows.append(["tone_consistency", s, t, f"{c:.3f}", "FLAG" if c < a.tone_min else "ok"])
    split = {s["speaker_id"]: s["split"] for s in spk}
    train = [s for s in neutral if split[s] == "train"]
    for s in neutral:
        if split[s] == "train":
            continue
        best = max(train, key=lambda x: float(neutral[s] @ neutral[x]))
        c = float(neutral[s] @ neutral[best])
        rows.append(["split_leakage", s, f"closest train speaker {best}", f"{c:.3f}",
                     "FLAG" if c > a.leak_max else "ok"])
    if a.clips:
        rec = list(csv.DictReader(open(ROOT / "metadata/recordings.csv")))
        rng = random.Random(0)
        for s in neutral:
            mine = [r for r in rec if r["speaker_id"] == s]
            for r in rng.sample(mine, min(a.clips, len(mine))):
                c = float(neutral[s] @ emb(str(ROOT / r["audio_filepath"]) if not Path(r["audio_filepath"]).is_absolute()
                                           else r["audio_filepath"]))
                rows.append(["clip_fidelity", s, r["sample_id"], f"{c:.3f}", "FLAG" if c < a.tone_min else "ok"])
    with open(ROOT / "metadata/speaker_check.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["check", "speaker_id", "detail", "cosine", "result"])
        w.writerows(rows)
    for kind in ("tone_consistency", "split_leakage", "clip_fidelity"):
        sel = [r for r in rows if r[0] == kind]
        if sel:
            fl = [r for r in sel if r[4] == "FLAG"]
            print(f"{kind}: {len(sel)} checked, {len(fl)} flagged")
            for r in fl[:20]:
                print("   ", r[1], r[2], r[3])
    print("details -> metadata/speaker_check.csv")


if __name__ == "__main__":
    main()
