"""
Synthesise Household-SLU with Qwen3-TTS (VoiceDesign + Base), following metadata/tts_jobs.csv.

Stage 1 (refs) : for every speaker and every tone it needs, VoiceDesign speaks the tone's reference
                 sentence with "<speaker description>, <tone phrase>" -> metadata/voice_refs/<spk>__<tone>.wav
                 (seeded per speaker so the voice stays as similar as possible across tones).
Stage 2 (clone): the Base model clones each reference and reads all of that speaker's sentences in that tone
                 -> audio_raw/<split>/<speaker>/hh-<slurp_id>-<speaker>.wav   (24 kHz, as produced)

Pitch, accent, age, timbre and pace come from each speaker's description (metadata/speakers.json),
tone varies per utterance (scripts/tones.py), speed perturbation is applied later by finalize.

  export HF_HUB_OFFLINE=1
  python scripts/synth_household_qwen3.py \
      --design ./Qwen3-TTS-12Hz-1.7B-VoiceDesign --base ./Qwen3-TTS-12Hz-1.7B-Base --batch_size 16
  options: --stage refs|clone|all  --splits devel test  --speakers spk001 spk002  --max_jobs 200
           --ref_seed_offset 1  (re-design refs you deleted, e.g. after check_speakers.py flagged them)

Resumable: existing files are skipped.
"""
import argparse, csv, json, re, sys, zlib
from collections import defaultdict
from pathlib import Path

import soundfile as sf
import torch
from qwen_tts import Qwen3TTSModel

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from tones import TONES  # noqa: E402

TTS_REPLACE = [(r"\bi\b", "I"), (r"\bi'(m|ve|d|ll)\b", r"I'\1"), (r"\btv\b", "TV"), (r"\be waste\b", "e-waste"),
               (r"\be reader\b", "e-reader"), (r"\bt shirts?\b", lambda m: m.group(0).replace("t ", "T-"))]
QUESTION_START = ("can ", "could ", "would ", "will ", "where ", "is ", "are ", "did ", "do ", "have ")


def tts_text(text):
    """'can you bring me my keys' -> 'Can you bring me my keys?' (labels keep the lowercase form)."""
    t = text
    for pat, rep in TTS_REPLACE:
        t = re.sub(pat, rep, t)
    return t[0].upper() + t[1:] + ("?" if text.startswith(QUESTION_START) else ".")


def load(path):
    return Qwen3TTSModel.from_pretrained(path, device_map="cuda:0", dtype=torch.bfloat16)


def chunks(x, n):
    for i in range(0, len(x), n):
        yield x[i:i + n]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--design", help="path to Qwen3-TTS-12Hz-1.7B-VoiceDesign")
    ap.add_argument("--base", help="path to Qwen3-TTS-12Hz-1.7B-Base")
    ap.add_argument("--stage", choices=["refs", "clone", "all"], default="all")
    ap.add_argument("--splits", nargs="*", default=["train", "devel", "test"])
    ap.add_argument("--speakers", nargs="*", default=None)
    ap.add_argument("--max_jobs", type=int, default=0, help="quick test: only the first N jobs")
    ap.add_argument("--batch_size", type=int, default=16)
    ap.add_argument("--language", default="English")
    ap.add_argument("--ref_seed_offset", type=int, default=0)
    a = ap.parse_args()

    spk = {s["speaker_id"]: s for s in json.load(open(ROOT / "metadata/speakers.json"))}
    jobs = [j for j in csv.DictReader(open(ROOT / "metadata/tts_jobs.csv"))
            if j["split"] in a.splits and (not a.speakers or j["speaker_id"] in a.speakers)]
    if a.max_jobs:
        jobs = jobs[:a.max_jobs]
    raw = ROOT / "audio_raw"
    ref_dir = ROOT / "metadata/voice_refs"
    ref_dir.mkdir(parents=True, exist_ok=True)
    need = sorted({(j["speaker_id"], j["tone"]) for j in jobs} | {(j["speaker_id"], "neutral") for j in jobs})
    print(f"{len(jobs)} jobs, {len({s for s, _ in need})} speakers, {len(need)} (speaker, tone) references")

    # ------------------------------------------------------------- stage 1: references
    if a.stage in ("refs", "all"):
        todo = [(s, t) for s, t in need if not (ref_dir / f"{s}__{t}.wav").exists()]
        if todo:
            assert a.design, "--design is required to create reference clips"
            design = load(a.design)
            for s, t in todo:
                # same seed for all tones of a speaker -> closer voice identity across tones
                torch.manual_seed(zlib.crc32(s.encode()) + a.ref_seed_offset)
                desc = f"{spk[s]['description'].rstrip('.')}, {TONES[t]['design']}."
                wavs, sr = design.generate_voice_design(text=[TONES[t]["ref_text"]], language=[a.language],
                                                        instruct=[desc])
                sf.write(ref_dir / f"{s}__{t}.wav", wavs[0], sr)
                print("ref", s, t, "|", desc)
            del design
            torch.cuda.empty_cache()

    # ------------------------------------------------------------- stage 2: cloning
    if a.stage in ("clone", "all"):
        groups = defaultdict(list)
        for j in jobs:
            if not (raw / j["file"]).exists():
                groups[(j["speaker_id"], j["tone"])].append(j)
        if not groups:
            print("nothing to synthesise")
            return
        assert a.base, "--base is required for cloning"
        base = load(a.base)
        log_path = ROOT / "metadata/synth_log.csv"
        new = not log_path.exists()
        log = open(log_path, "a", newline="")
        lw = csv.writer(log)
        if new:
            lw.writerow(["sample_id", "file", "speaker_id", "tone", "tts_text", "sample_rate", "seconds"])
        done = 0
        for (s, t), gj in sorted(groups.items()):
            ref = ref_dir / f"{s}__{t}.wav"
            if not ref.exists():
                print(f"missing reference {ref.name}, run --stage refs first"); continue
            prompt = base.create_voice_clone_prompt(ref_audio=str(ref), ref_text=TONES[t]["ref_text"])
            for batch in chunks(gj, a.batch_size):
                texts = [tts_text(j["text"]) for j in batch]
                try:
                    wavs, sr = base.generate_voice_clone(text=texts, language=[a.language] * len(texts),
                                                         voice_clone_prompt=prompt)
                except Exception as e:  # keep long runs alive
                    print(f"FAILED {s} {t} batch at {batch[0]['sample_id']}: {e}")
                    torch.cuda.empty_cache(); continue
                for j, txt, w in zip(batch, texts, wavs):
                    p = raw / j["file"]
                    p.parent.mkdir(parents=True, exist_ok=True)
                    sf.write(p, w, sr)
                    lw.writerow([j["sample_id"], j["file"], s, t, txt, sr, round(len(w) / sr, 3)])
                    done += 1
                log.flush()
            print(f"{s} {t}: {len(gj)} done ({done} total)")
        log.close()


if __name__ == "__main__":
    main()
