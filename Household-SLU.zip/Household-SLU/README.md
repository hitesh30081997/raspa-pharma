# Household-SLU

A single-domain spoken language understanding dataset for **service robots at home**, built to adapt
`nvidia/slu_conformer_transformer_large_slurp` to a new domain with new intents and slots.

* Scenario: `household` (not a SLURP scenario)
* **30 intents**, none of which exists in SLURP, in name or in meaning: every intent is a physical household task for the robot.
  Lights, smart plugs, coffee, vacuum cleaning, volume, alarms, lists, recipes and takeaway, all of which SLURP covers,
  are deliberately left out. None of the 30 action names is a SLURP action, and none of the 3,000 sentences is identical
  to a SLURP sentence (checked against the user's SLURP inventory).
* **22 slot types**, used consistently (a shirt is always `garment`, a phone always `gadget`); `location` = where
  something is or where the task happens, `destination` = where something goes. `time`, `date` and `person` keep their SLURP names.
* **3,000 unique annotated commands** (100 per intent), split by sentence 80 / 10 / 10 per intent.
* **50 English speakers** (Qwen3-TTS designed voices), **disjoint** across splits: 38 train / 6 devel / 6 test.
* **30,000 audio samples** planned: train 26,400 (each train sentence read by 11 different train speakers),
  devel 1,800 and test 1,800 (each sentence read by all 6 speakers of its split).
* Same structure as SLURP: `dataset/household/{train,devel,test}.jsonl` with `slurp_id`, `sentence`,
  `sentence_annotation`, `intent`, `action`, `scenario`, `tokens`, `entities` (token spans), `recordings`,
  plus NeMo manifests whose `text` is the semantics string the model is trained on.

## Intents

| # | Intent | What the robot does | Slot types | Example |
|---|---|---|---|---|
| 1 | `household_fetch_item` | Bring an object to the speaker. | bag, color, gadget, garment, item, linen, location | i'm feeling cold bring me my [linen : blanket] |
| 2 | `household_put_away` | Return an object to where it is stored. | bag, destination, dish, gadget, garment, item, location | the [item : water bottle] is lying on the [location : kitchen counter] put it back in the [destination : chest of drawers] |
| 3 | `household_find_item` | Search for and locate a lost object. | color, gadget, garment, item, location | find the [color : grey] [garment : blouse] |
| 4 | `household_open_item` | Open a door, window, drawer, appliance door or curtains. | fixture, location, person | open the [fixture : window] in the [location : kids room] |
| 5 | `household_close_item` | Close or shut a door, window, drawer or curtains. | fixture, location | slide the [fixture : balcony door] shut |
| 6 | `household_load_dishwasher` | Put dirty dishes into the dishwasher. | dish, location, meal, time | put the [dish : spoons] in the dishwasher |
| 7 | `household_unload_dishwasher` | Take clean dishes out of the dishwasher. | destination, dish, time | empty the dishwasher and put the [dish : forks] in the [destination : drawer] |
| 8 | `household_wash_dishes` | Wash dishes by hand at the sink. | dish, meal, time | there's a pile of [dish : mugs] in the sink wash them |
| 9 | `household_set_table` | Lay the table for a meal. | dish, linen, location, meal, person, quantity, time | we're having [meal : brunch] soon please set the table |
| 10 | `household_clear_table` | Clear dishes and leftovers off the table. | destination, dish, food, location, meal, time | clear away the [dish : baking tray] |
| 11 | `household_serve_food` | Serve food or a meal to people. | food, location, meal, person, time | serve a plate of [food : biryani] to [person : zoya] |
| 12 | `household_pour_drink` | Pour a drink into a glass or cup. | drink, person, quantity | pour a glass of [drink : milk] for the [person : children] |
| 13 | `household_load_laundry` | Put dirty laundry into the washing machine. | color, garment, linen, location, time | put the [garment : uniform] in the washing machine |
| 14 | `household_unload_laundry` | Take laundry out of the washer or dryer. | color, destination, garment, linen, time | get the [color : blue] [garment : pajamas] out of the washing machine |
| 15 | `household_fold_laundry` | Fold clean clothes or linen. | color, destination, garment, linen, location, person, time | there's a pile of laundry on the [location : study table] fold it |
| 16 | `household_hang_clothes` | Hang clothes to dry or on hangers. | color, destination, garment, linen, time | it's sunny outside hang the clothes on the [destination : terrace] |
| 17 | `household_iron_clothes` | Iron or press clothes. | color, date, garment, linen, person, time | i have a meeting [date : on saturday] please iron my [garment : school uniform] |
| 18 | `household_make_bed` | Make a bed. | linen, location, person, time | the bed in the [location : upstairs bedroom] is messy make it |
| 19 | `household_change_bedsheets` | Replace the sheets or covers on a bed. | color, date, linen, location, person | the [linen : bedsheets] are dirty change them |
| 20 | `household_water_plants` | Water plants or the garden. | date, location, plant, time | the [plant : sunflowers] look dry please water them |
| 21 | `household_feed_pet` | Feed or give water to a pet. | pet, quantity, time | give the [pet : parrot] [quantity : two] scoops of food |
| 22 | `household_take_out_trash` | Take garbage out of the house. | date, destination, location, time, waste | the [location : store room] smells take out the trash |
| 23 | `household_sort_recycling` | Separate waste into recycling categories. | destination, time, waste | there's a lot of [waste : plastic waste] in the kitchen sort it for recycling |
| 24 | `household_tidy_room` | Declutter and organise a room or area. | item, location, person, time | tidy up the [location : kids room] |
| 25 | `household_store_groceries` | Unpack groceries and put them where they belong. | destination, drink, food, location | the [food : butter] will spoil put it in the [destination : kitchen cabinet] |
| 26 | `household_pack_bag` | Pack a bag, suitcase or lunch box. | bag, date, food, gadget, garment, item, person, quantity, time | i'm leaving [time : in half an hour] please pack my [bag : lunch box] |
| 27 | `household_carry_object` | Move a bulky object from one place to another. | destination, item, location, time | shift the [item : chair] to the [destination : store room] |
| 28 | `household_inspect_home` | Check the state of an appliance, door or window. | appliance, fixture, location, state | is the [appliance : heater] [state : running] in the [location : bathroom] |
| 29 | `household_answer_door` | Answer the door, see who is there or receive a delivery. | fixture, item, person | go and check who is at the [fixture : gate] |
| 30 | `household_charge_device` | Put a phone, laptop or other gadget on charge. | gadget, location, person, time | i need my [gadget : smartwatch] fully charged [time : in an hour] |

## Slot types

| Slot type | Occurrences | Unique fillers | Examples |
|---|---|---|---|
| `item` | 379 | 77 | wallet, keys, bicycle, tool box, notebook, magazine |
| `gadget` | 167 | 15 | bluetooth speaker, smartwatch, power bank, electric toothbrush, phone, laptop |
| `garment` | 301 | 35 | blouse, trousers, dress, jacket, shirt, uniform |
| `linen` | 228 | 22 | pillow covers, bedsheets, duvet cover, pillowcases, bed sheet, fitted sheet |
| `dish` | 301 | 27 | wine glasses, spoons, frying pan, knives, cups, serving bowls |
| `food` | 145 | 49 | cookies, salad, pasta, noodles, biscuits, biryani |
| `meal` | 120 | 6 | brunch, dinner, lunch, evening snacks, supper, breakfast |
| `drink` | 116 | 21 | lemonade, cold water, apple juice, smoothie, warm milk, tea |
| `plant` | 94 | 20 | cactus, indoor plants, tomato plants, tulsi plant, flower pots, roses |
| `pet` | 107 | 22 | puppy, hamster, fish, rabbit, birds, goldfish |
| `person` | 228 | 48 | kids, children, neighbours, family, visitors, guests |
| `location` | 525 | 61 | master bedroom, guest room, spare room, kids room, breakfast table, dining room |
| `destination` | 280 | 72 | cupboard, top shelf, kitchen cabinet, backyard, vegetable drawer, fridge |
| `fixture` | 291 | 32 | main door, front door, door, gate, back door, balcony door |
| `appliance` | 50 | 19 | rice cooker, washing machine, heater, iron, hair dryer, hair straightener |
| `state` | 89 | 15 | unplugged, open, locked, closed, shut, plugged in |
| `bag` | 112 | 17 | overnight bag, travel bag, gym bag, tiffin box, suitcase, lunch box |
| `waste` | 188 | 20 | plastic waste, cardboard boxes, glass bottles, food waste, paper, garbage |
| `quantity` | 54 | 7 | five, two, four, ten, eight, three |
| `color` | 72 | 14 | grey, orange, pink, brown, blue, yellow |
| `time` | 167 | 20 | in half an hour, around four, at seven am, at nine pm, at noon, at eight thirty |
| `date` | 61 | 14 | today, day after tomorrow, sunday, on sunday, tomorrow, on friday |

## Speakers and variation

| Varies | How | Levels |
|---|---|---|
| Accent | per speaker | General American, Southern American, British RP, Northern English, Scottish, Irish, Australian, Indian English, South African, Nigerian English (5 speakers each) |
| Gender | per speaker | 25 female, 25 male |
| Age | per speaker | teenage, young adult, thirties, middle-aged, elderly (every gender × age × accent combination is used at most once) |
| Pitch, timbre, pace, manner | per speaker | e.g. "deep, low-pitched", "husky", "fast pace", "brisk" |
| Tone | per utterance | neutral 25%, friendly 15%, cheerful, calm, tired, impatient, hurried, sad 10% each |
| Speed | per utterance, train only | 0.9× (20%), 1.0× (60%), 1.1× (20%) speed perturbation |
| Phrasing | per sentence | direct commands, 22 polite / indirect wrappers ("could you…", "hey robot…", "when you get a chance…"), and stated needs ("i'm thirsty pour me some lemonade") |

Every speaker's full description is in `metadata/speakers.json` / `speakers.csv`.

* **devel speakers:** spk015 (female, teen, uk rp); spk022 (male, young adult, scottish); spk029 (female, young adult, irish); spk034 (male, thirties, australian); spk037 (female, elderly, indian); spk046 (male, elderly, nigerian)
* **test speakers:** spk001 (female, teen, us general); spk009 (female, thirties, us southern); spk011 (female, thirties, uk rp); spk020 (male, young adult, uk northern); spk030 (male, middle aged, irish); spk036 (male, thirties, indian)

Every accent in devel/test is also spoken by other speakers in train, so the split tests **new voices**, not new accents.

## Folder structure

```
Household-SLU/
├── source/household_templates.py      intents, slot word lists, sentence templates (edit here)
├── dataset/household/{train,devel,test}.jsonl   SLURP-format records (recordings filled by finalize)
├── text/sentences.txt                 3,000 commands, one per line
├── text/sentences_annotated.tsv       slurp_id, split, intent, sentence, annotation
├── metadata/
│   ├── ontology.json                  intents, slot types, tone weights
│   ├── speakers.json / speakers.csv   50 voices, attributes, split
│   ├── tts_jobs.csv                   30,000 rows: sample_id, slurp_id, split, speaker, tone, speed, text, file
│   ├── build_report.txt               counts and checks
│   ├── voice_refs/                    (created) one reference clip per speaker × tone
│   ├── synth_log.csv, asr_check.csv, recordings.csv, speaker_check.csv   (created)
├── audio_raw/<split>/<speaker>/hh-<slurp_id>-<speaker>.wav   (created) 24 kHz TTS output
├── audio/<split>/<speaker>/...wav     (created) 16 kHz mono PCM-16, speed-perturbed
├── manifests/{train,devel,test}_slu.json   (created) NeMo manifests
└── scripts/
    ├── build_household.py             regenerates text, speakers and the job list
    ├── tones.py                       tone definitions
    ├── synth_household_qwen3.py       Qwen3-TTS: tone references (VoiceDesign) + cloning (Base)
    ├── check_speakers.py              ECAPA checks: tone consistency, split leakage, clone fidelity
    ├── asr_filter_household.py        Whisper check: sentence WER and slot-filler errors
    ├── finalize_household.py          16 kHz + speed perturbation, NeMo manifests, SLURP recordings
    ├── finetune_household.py          fine-tune the full pretrained SLURP model (NeMo)
    └── eval_household.py              intent accuracy, slot F1, per-intent accuracy, confusions
```

SLURP-format record (before audio):
```json
{"slurp_id": 900091, "sentence": "if you are free bring me my car keys", "sentence_annotation": "if you are free bring me my [item : car keys]", "intent": "household_fetch_item", "action": "fetch_item", "tokens": [{"surface": "if", "id": 0, "lemma": "if", "pos": null}, {"surface": "you", "id": 1, "lemma": "you", "pos": null}, {"surface": "are", "id": 2, "lemma": "are", "pos": null}, {"surface": "free", "id": 3, "lemma": "free", "pos": null}, {"surface": "bring", "id": 4, "lemma": "bring", "pos": null}, {"surface": "me", "id": 5, "lemma": "me", "pos": null}, {"surface": "my", "id": 6, "lemma": "my", "pos": null}, {"surface": "car", "id": 7, "lemma": "car", "pos": null}, {"surface": "keys", "i...
```
NeMo manifest line:
```json
{"audio_filepath": "audio/test/spk001/hh-900091-spk001.wav", "offset": 0.0, "duration": 1.9,
 "text": "{'scenario': 'household', 'action': 'fetch_item', 'entities': [{'type': 'item', 'filler': 'car keys'}]}"}
```

## Producing the audio

```bash
pip install qwen-tts soundfile scipy numpy speechbrain faster-whisper num2words
export HF_HUB_OFFLINE=1
# 1. reference clips: 50 speakers x 8 tones = 400 short clips
python scripts/synth_household_qwen3.py --stage refs --design ./Qwen3-TTS-12Hz-1.7B-VoiceDesign
# 2. listen to a few in metadata/voice_refs/ and check speaker consistency / split leakage
python scripts/check_speakers.py          # delete flagged refs, then rerun step 1 with --ref_seed_offset 1
# 3. clone: 30,000 clips (try --splits devel first, or --max_jobs 200 for a quick test)
python scripts/synth_household_qwen3.py --stage clone --base ./Qwen3-TTS-12Hz-1.7B-Base --batch_size 16
# 4. drop clips whose words or slot fillers were not spoken correctly
python scripts/asr_filter_household.py --max_wer 0.2 --max_ent_wer 0.0
# 5. 16 kHz audio, speed perturbation, NeMo manifests, SLURP recordings
python scripts/finalize_household.py --absolute
python scripts/check_speakers.py --clips 5   # optional: clone fidelity on final clips
```
Every step can be resumed. Labels keep SLURP's lowercase spoken form; only the TTS input is capitalised
and punctuated (`can you bring me my keys` → `Can you bring me my keys?`).

The ASR check will drop some clips, so the final count will be a little under 30,000. To end up with at least
30,000 after filtering, rebuild with more train readers: `python scripts/build_household.py --train_readers 12`
(32,400 planned).

## Fine-tuning the NVIDIA SLURP model

`scripts/finetune_household.py` loads the **complete** pretrained `slu_conformer_transformer_large_slurp`
(encoder, decoder and its 58-token SentencePiece tokenizer) and continues training on Household-SLU.
NeMo's own `run_speech_intent_slot_train.py` is not used because it builds a new model whose decoder starts from scratch.

```bash
pip install "nemo_toolkit[asr]"
# 0. zero-shot baseline (expect ~0% intent accuracy: the household labels are new)
python scripts/eval_household.py --model slu_conformer_transformer_large_slurp --out eval_zeroshot
# 1. full fine-tuning (checks first that every label can be encoded by the SLURP tokenizer)
python scripts/finetune_household.py --epochs 30 --batch_size 32 --lr 1e-4 --warmup_steps 500
# 2. evaluate on the test set (new sentences + new speakers)
python scripts/eval_household.py --model nemo_experiments/household_slu_ft.nemo --out eval_ft
```
Variants: `--freeze_encoder` (decoder only, faster, less forgetting), `--replay_manifest <SLURP train manifest>`
(keep SLURP performance), `--devices 2` (multi-GPU). For beam search and the official SLURP-F1, run NeMo's
`examples/slu/speech_intent_slot/run_speech_intent_slot_eval.py` with `dataset_manifest=manifests/test_slu.json`.

* Keep the pre-trained tokenizer; the new action and slot names are spelled with its existing sub-word pieces.
* Sentences repeat across 11 voices, so watch the devel loss for over-fitting.
* The test set is new sentences **and** new voices. For a harder test, also record a few hundred real commands.

## Build report
```
intents: 30   slot types: 22   unique sentences: 3000
sentences per split: train=2400, devel=300, test=300
speakers: 50 -> train=38, devel=6, test=6
speaker sets disjoint: True
audio samples: train=26400, devel=1800, test=1800  total=30000
train sentences per train speaker: min=694 max=695
tones: neutral=7445, friendly=4400, sad=3119, cheerful=3086, tired=3054, hurried=3004, impatient=2947, calm=2945
speeds (train): 0.9=5214, 1.0=15935, 1.1=5251
action names shared with SLURP: none   scenario in SLURP: False
sentences identical to a SLURP sentence: 0
devel speakers: spk015 female teen uk_rp; spk022 male young_adult scottish; spk029 female young_adult irish; spk034 male thirties australian; spk037 female elderly indian; spk046 male elderly nigerian
test speakers: spk001 female teen us_general; spk009 female thirties us_southern; spk011 female thirties uk_rp; spk020 male young_adult uk_northern; spk030 male middle_aged irish; spk036 male thirties indian
```
